# Eight-item personal confirmation: rater2

Extract the entire ZIP and open START_HERE.html. Complete Wording_boundary_confirmation_rater2.xlsx, then save as Wording_boundary_confirmation_rater2_completed.xlsx. Read the exposure/scope statement before beginning. Decisions, reasons, annotation, name and date are blank. No agreement or particular outcome is requested.
