# Rubric v2 approved as written

Registered: 2026-09-18
Version: `rubric-v2-draft-for-limited-evidence-v3.1`

Both original returned workbooks record **Approve as written**. Each reviewer accepted all 8 policies, 20 case requirements, 9 error definitions and 42 examples: 79 decisions per reviewer. This administrative record does not create or replace an expert signature.

- [Rater1 confirmation](Expert_rubric_review_v2_rater1.xlsx)
- [Rater2 confirmation](Expert_rubric_review_v2_rater2.xlsx)
- [Approval record, hashes and literal comments](APPROVAL_RECORD.json)

All reviewed proposal cells match the unchanged blank template. All 10 output files in the pre-review manifest retain their hashes. Rater1's seven recorded material hashes also match. Both returns were checked for the expected version, reviewer identity, complete decisions and English text. The approved v3.1 model inputs remain unchanged.

## Scope and preserved historical status

Approval covers the prospective rubric and this five-case development annex. It does not approve outcome weights, a new formal sample, new-case requirements, statistical analysis, technical-failure exclusions or a model-generation batch. Previous reports, scores and adjudications remain unchanged.

The directory name, version identifier, original documents, template and manifest retain their draft/pending wording and exact reviewed bytes. This dated approval record supersedes those earlier status labels within the stated scope. Do not rename the version or rewrite the reviewed documents merely to remove draft wording.

## Non-blocking observations

1. **Coverage-form fields:** rater2 suggests capturing `contradicted_elsewhere` and issue links so future analysis can distinguish covered assertions with and without contradictions. The reviewed Future rating fields sheet already includes `adjudication_status`. Consider the additional field when constructing the next rating forms; no reviewed workbook has been edited here.
2. **Sub09 C04 wording:** rater2 proposes replacing meaningful with more explicit identification of the standardized deviation and above-mean direction. Both approved the current wording. Do not interpret meaningful as a requirement to assert clinical significance or exceed an unavailable percentile; retain the current as-written version.
3. **X32:** rater1 accepts the exact explicitly qualified descriptive example, not a validated moderate category. Rater2's suggested bare-form example is a non-blocking proposal, not a jointly approved replacement. Do not treat their approval as agreement that all values between the median and p95 are moderate, or as categorical approval of every unqualified degree word. Apply the confirmed contextual rules; submit any new calibration example separately if needed.

## Next stage

Prepare an exposure and eligibility ledger before selecting the formal sample. Distinguish previously inspected development cases from potential held-out cases, verify missing-data/side/reference policies and resolve the Sub43 event flag as applicable. Then prepare sample-specific requirements, the outcome/analysis specification, generation/failure rules and rating forms for the appropriate expert/study-lead decisions.

No new report generation is authorized by this approval record.
