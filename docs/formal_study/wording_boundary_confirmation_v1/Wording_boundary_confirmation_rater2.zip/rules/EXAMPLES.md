# Revised scoring examples

All 42 examples are newly authored teaching examples, not actual model responses or expert judgments. All decisions remain proposed until this rubric version is confirmed. Case-specific numbers apply only to their identified input.

## X01: G03

> The reference is not individually matched, so these differences cannot isolate a stroke effect.

**Proposed assessment:** Covered

Both meanings are present; no age/speed word checklist.

## X02: G03

> The reference is pooled.

**Proposed assessment:** Not covered in isolation

A source label alone conveys neither required limitation. With one meaningful limitation supplied elsewhere, the combined report may be Partially covered.

## X03: G03

> These comparisons cannot separate slow-speed and stroke effects. Later: the deviation proves stroke-specific dysfunction.

**Proposed assessment:** Covered plus separate error

First statement conveys both meanings; assess the later unsupported assertion separately.

## X04: Sub09 C04

> ST and VL each have max |z| 4.2; at those locations, both envelopes are above their phase-specific reference means. Their muscle-specific percentile classification is indeterminate from the supplied endpoints.

**Proposed assessment:** Covered

Sub09 C04: both complete numerical routes; cycle locations are optional for this item. Standardized magnitude is syntactically separate from above-mean envelope direction.

## X05: Sub09 C04

> There is insufficient information to classify EMG normality.

**Proposed assessment:** Not covered

Correct general caution does not describe the required ST/VL findings.

## X06: Sub09 C04

> ST and VL have broad detected intervals extending across the initial-contact boundary, approximately 83 to 44% and 88 to 48%.

**Proposed assessment:** Covered

Complete interval alternative; numerical z route is not additionally required.

## X07: Sub05 C04

> ST and VL are elevated relative to the mean reference at 35% and 5%.

**Proposed assessment:** Partially covered plus E01

ST is correct; VL direction is wrong. Distinguish coverage of the components from the erroneous assertion.

## X08: Sub05 TA optional

> The displayed TA max |z| is 4.6, below the displayed 4.61 endpoint; this does not settle its unrounded classification or clinical normality.

**Proposed assessment:** Acceptable optional description

Visible-number comparison only; no omission penalty if TA is not discussed.

## X09: Sub50 ST

> ST max |z| 4.7 exceeds the highest supplied pooled endpoint, 4.61; this is a descriptive comparison, not a diagnosis.

**Proposed assessment:** Acceptable optional comparison

Do not require a hidden ST-specific percentile. In isolation this optional comparison does not fully cover Sub50 C03: above-mean direction and approximate location are still needed.

## X10: Control Sub49

> GPS-like 3.75 is below pooled p95 10.7, confirming normal gait.

**Proposed assessment:** E05

Pooled background cannot establish overall normality for this LOO-based score.

## X11: Sub09 CCI optional

> RF-BF CCI 0.82 is within 0.48-0.83, near the upper endpoint.

**Proposed assessment:** Acceptable optional description

Describes the index under the stated method.

## X12: Sub09 CCI optional

> RF-BF CCI 0.82 confirms physiologically normal antagonist co-activation.

**Proposed assessment:** E06

New prospective boundary; no retrospective change to Q055.

## X13: Sub09 RF threshold coverage

> The supplied summary reports RF above threshold for 100% of the cycle.

**Proposed assessment:** Acceptable optional description

Faithful to displayed coverage; does not claim every sample or every stride is continuously active.

## X14: Sub09 RF threshold coverage

> 100% threshold coverage proves tonic pathological contraction with no rest.

**Proposed assessment:** E03

Unsupported conversion from algorithm property to physiology.

## X15: Sub05 TA event anchor

> TA maximum standardized difference occurs at the 0% initial-contact boundary.

**Proposed assessment:** Acceptable optional description

Sub05 explicitly supplies the TA max-|z| location at 0%. The event anchor alone would not establish a muscle maximum there. This is not an amplitude peak or physiological onset.

## X16: Sub05 GAS phase and anatomy

> GAS is a plantarflexor, so its maximum standardized difference at 80% of the cycle reflects impaired push-off.

**Proposed assessment:** E04

The supplied Sub05 location is a maximum standardized difference, not an interval or phase. Anatomical naming is allowed; the inferred phase function is not.

## X17: Sub47 C03

> EMG was unavailable, so envelope timing, amplitude and CCI cannot be assessed.

**Proposed assessment:** Covered

Sufficient EMG section; no invented additional content needed.

## X18: Sub47 C03

> No EMG activity was measured, therefore these muscles were inactive.

**Proposed assessment:** E08

No recordings is not physiological inactivity. The ambiguous phrase no EMG activity was measured does not itself establish coverage of missing recordings; inspect the whole report.

## X19: Control C06

> This is a healthy control compared with a leave-one-out reference excluding the participant.

**Proposed assessment:** Covered for complete C06 when no conditional domain is discussed

If speed/cadence/symmetry are not discussed, no compulsory missing-field inventory is added.

## X20: Control C06

> Speed and cadence were not supplied; the paretic/non-paretic step-length index is not applicable to this control.

**Proposed assessment:** Acceptable conditional statements

General left/right symmetry remains definable, but is not this metric. These conditional statements alone do not cover C06 provenance and self-exclusion.

## X21: Step index

> An index of -23.1% means the paretic step is exactly 23.1% shorter than the non-paretic step.

**Proposed assessment:** E01

The normalized difference formula uses a different denominator.

## X22: Clinical questions

> Would direct strength testing help assess a possible contribution of weakness?

**Proposed assessment:** Acceptable optional question

Open question does not assert measured weakness.

## X23: Clinical questions

> What treatment should correct the confirmed plantarflexor weakness?

**Proposed assessment:** E02

The question presupposes an unsupported confirmed deficit.

## X24: Methodological statement

> Repeating the trial at matched speed would eliminate every confound.

**Proposed assessment:** Design concern; excluded from case-error tally under P07

Record the unsupported methodological guarantee separately; do not label it clinically validated. Prospective scope requires explicit expert agreement.

## X25: Sub05 VL contradiction

> VL is below the reference mean at about 5%. Later: VL is above the reference mean at 5%.

**Proposed assessment:** Covered for direction; separate E01 for unretracted false assertion

The correct direction/location is explicit; the later unretracted opposite assertion is false. Other C04 components, including ST, must still be checked before assigning whole-row coverage.

## X26: Sub05 VL wrong-only direction

> VL is above the reference mean at 5%.

**Proposed assessment:** VL direction not covered; E01

No correct VL direction is asserted. With correct ST and other substantive C04 content elsewhere the row is Partially covered; do not automatically label every wrong-only row partial.

## X27: Sub05 VL explicit correction

> Correction: the earlier statement that VL was above the mean was wrong; VL is below the reference mean at approximately 5%.

**Proposed assessment:** Accept corrected below-mean direction in context

The false direction is explicitly retracted, not an additional endorsed claim. Assess whether the final wording actually corrects the report.

## X28: Mixed design and case assertion

> Matching speed removes every confound, so this participant's deviation proves stroke dysfunction.

**Proposed assessment:** Design concern plus E09; cross-linked

Separate the universal design guarantee from the participant-specific causal assertion. Do not exclude the latter because it shares a sentence.

## X29: Metric identity

> This participant's GPS-like score combines temporal and spatial walking parameters.

**Proposed assessment:** E01 case error

Misstates the supplied kinematic metric; this is not excluded as general design advice.

## X30: Sub50 SL01 scoped finding

> The index is -0.7%, with a marginally shorter paretic step and a small difference by this step-length definition.

**Proposed assessment:** Covered; no disclaimer required

Conveys index and near-zero meaning. Does not assert whole-gait normality or overall symmetry.

## X31: Sub50 SL01 overgeneralization

> The -0.7% index is near zero, proving overall gait symmetry.

**Proposed assessment:** Covered for the finding plus E07

The required finding is conveyed; the unsupported whole-gait conclusion is separately recorded. Do not turn the absent disclaimer into an omission.

## X32: Sub50 descriptive magnitude anchored to visible background

> GPS-like 6.86 is above the supplied median 5.1 and below pooled p95 10.7; moderate here describes that relative position, not a clinical severity class.

**Proposed assessment:** Proposed acceptable descriptive wording; no severity grade

The visible comparison anchors the intended descriptive meaning. It does not establish a validated moderate category. This new example specifically requires expert confirmation.

## X33: Sub05 unanchored degree word

> The -23.1% step-length index indicates marked asymmetry.

**Proposed assessment:** Pending adjudication; not automatic Error

No matched severity reference is supplied. Read marked in context and document whether it asserts a clinical grade or informal emphasis; do not settle the decision by a prohibited-word list.

## X34: Control Sub49 timing normality

> The muscle intervals are consistent with normal gait phasing.

**Proposed assessment:** E04; E05 may be an additional tag, not a second event

Neither control membership nor the initial-contact anchor supplies the missing normal muscle timing references.

## X35: Sub05 TA prohibited onset claim

> TA activation begins at initial contact because its maximum standardized difference occurs at 0%.

**Proposed assessment:** E03; E04 may be an additional tag

Naming the supplied boundary is allowed in X15; transforming the max-z location into physiological onset is unsupported.

## X36: Duplicate presupposition

> Section 2: plantarflexor weakness is confirmed. Section 4: what drives the confirmed plantarflexor weakness?

**Proposed assessment:** One issue group, both locations

The question presupposes the same unsupported deficit; link it to the existing E02 claim rather than count a second occurrence as another independent issue.

## X37: Explicit statistical claim

> The supplied max |z| establishes a statistically significant deviation, p < 0.05.

**Proposed assessment:** E02; E05 may also tag the same claim

No hypothesis test or p value was supplied. This is different from an ambiguous colloquial use of significant.

## X38: Administrative missingness versus actual short output

> The complete captured model output is: Walking speed is 0.62 m/s.

**Proposed assessment:** Assess actual captured content; no automatic Cannot assess

Rate assessable case content and missing requirements; record short output/format. If the stored file itself is incomplete relative to what was generated, obtain the correct material. Any exclusion follows a separate prespecified technical-failure rule.

## X39: Sub09 C04 names only

> ST and VL.

**Proposed assessment:** Not covered

Muscle names alone are not substantive findings and earn no partial coverage.

## X40: Sub50 C02 omitted excursion contrast

> The pelvis has the largest GVS, with the knee also prominent.

**Proposed assessment:** Partially covered

The required contrast with the small measured pelvic excursion is absent. Exact numerical repetition is optional; the contrast is not.

## X41: Sub05 ambiguous VL alternative

> VL may be either above or below the reference mean.

**Proposed assessment:** Coverage adjudication pending; do not use Cannot assess

No unambiguous correct direction is asserted. Record the competing reading and resolve before final coverage rather than infer credit from the word below.

## X42: Explicit clinical severity grade

> The -23.1% step-length index places this participant in a validated severe clinical impairment class.

**Proposed assessment:** E02

A specific validated clinical grade is asserted without a supplied basis. Unlike informal marked in X33, this claim is explicitly classificatory.

