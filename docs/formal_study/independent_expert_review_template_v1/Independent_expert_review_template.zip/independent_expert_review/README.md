# Independent expert review template

Extract the whole ZIP and open START_HERE.html. Read ORIENTATION.html before scoring. Record judgments only in a separate copy of Independent_ratings.xlsx. All scores and confirmations are blank. Use the fixed reading order and the frozen requirements. Do not consult other reviewers until all independent submissions are locked.
