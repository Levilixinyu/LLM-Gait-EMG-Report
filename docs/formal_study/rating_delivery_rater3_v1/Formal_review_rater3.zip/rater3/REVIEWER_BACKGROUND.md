# Reviewer background: rater3

Complete a separate copy named Reviewer_background_rater3_completed.md.
These fields describe the reviewer; they are not report scores or a signature.
Do not replace blank fields with assumed credentials or confirmations.

- Reviewer name:
- Professional role and specialty:
- Institution / department:
- Years of relevant clinical practice:
- Experience interpreting gait kinematics and surface EMG:
- Relevant research or scoring experience:
- Prior involvement with this dataset, reports, or study (describe any):
- Access to other formal ratings, model identities, or disagreement discussions (describe any):
- Relevant conflicts of interest (state None only if applicable):
- Orientation, full rubric, error definitions and examples read (Yes only after reading):
- Questions needing clarification before scoring:
- Date (YYYY-MM-DD):
